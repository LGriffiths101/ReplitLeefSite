import { db } from './db';
import { products, articles, users } from '@shared/schema';

const seedProducts = [
  {
    name: 'CBD Massage Balm',
    slug: 'cbd-massage-balm',
    description: 'Our premium CBD Massage Balm is expertly formulated to provide soothing relief for muscles and joints. Perfect for post-workout recovery, this balm combines the therapeutic benefits of high-quality CBD with natural anti-inflammatory ingredients. The rich, luxurious texture absorbs quickly into the skin, delivering targeted relief where you need it most.',
    shortDescription: 'Soothing relief for muscles and joints. Perfect for post-workout recovery with natural anti-inflammatory properties.',
    price: '24.99',
    vatRate: '0.2000',
    category: 'massage',
    imageUrl: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600',
    imageAlt: 'Leef CBD Massage Balm jar with natural ingredients',
    ingredients: 'CBD Isolate (500mg), Coconut Oil, Shea Butter, Beeswax, Arnica Extract, Eucalyptus Oil, Lavender Oil, Vitamin E',
    usageInstructions: 'Apply a small amount to clean skin and massage gently into the affected area. Use as needed, up to 3-4 times daily. For external use only. Avoid contact with eyes and mucous membranes.',
    benefits: 'May help reduce muscle tension and discomfort\nSupports natural recovery processes\nNourishes and moisturizes skin\nContains anti-inflammatory botanicals\nFast-absorbing, non-greasy formula',
    stockQuantity: 25,
    isActive: true,
    featured: true,
    weight: '50ml',
    cbdContent: '500mg CBD',
    thcContent: '< 0.2%',
    labTestCertUrl: 'https://example.com/lab-cert-massage-balm.pdf',
  },
  {
    name: 'Roll On Active Balm',
    slug: 'roll-on-active-balm',
    description: 'Experience convenient, on-the-go relief with our Roll On Active Balm. This innovative applicator delivers targeted CBD relief exactly where you need it, making it perfect for busy lifestyles. The unique formula combines cooling menthol with warming CBD to provide immediate comfort and long-lasting support.',
    shortDescription: 'Convenient on-the-go relief. Easy application for targeted areas with cooling menthol and warming CBD blend.',
    price: '19.99',
    vatRate: '0.2000',
    category: 'active',
    imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600',
    imageAlt: 'Leef Roll On Active Balm with modern applicator design',
    ingredients: 'CBD Isolate (300mg), Fractionated Coconut Oil, Menthol, Camphor, Peppermint Oil, Wintergreen Oil, Vitamin E',
    usageInstructions: 'Roll directly onto clean skin and massage gently if desired. Use as needed throughout the day. The convenient roll-on applicator ensures mess-free application. For external use only.',
    benefits: 'Immediate cooling sensation followed by warming comfort\nPerfect for on-the-go application\nMess-free roll-on applicator\nQuick absorption\nIdeal for active lifestyles',
    stockQuantity: 30,
    isActive: true,
    featured: true,
    weight: '30ml',
    cbdContent: '300mg CBD',
    thcContent: '< 0.2%',
    labTestCertUrl: 'https://example.com/lab-cert-roll-on.pdf',
  },
  {
    name: 'CBD Facial Cream',
    slug: 'cbd-facial-cream',
    description: 'Transform your daily skincare routine with our luxurious CBD Facial Cream. This advanced formula combines premium CBD with nourishing botanicals and vitamins to hydrate, soothe, and balance sensitive skin. Perfect for all skin types, this cream helps maintain healthy, radiant skin while providing the calming benefits of CBD.',
    shortDescription: 'Nourishing daily skincare with CBD. Hydrates and soothes sensitive skin with natural botanicals and vitamins.',
    price: '32.99',
    vatRate: '0.2000',
    category: 'skincare',
    imageUrl: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600',
    imageAlt: 'Leef CBD Facial Cream jar with natural skincare ingredients',
    ingredients: 'CBD Isolate (200mg), Hyaluronic Acid, Jojoba Oil, Aloe Vera Extract, Chamomile Extract, Vitamin C, Vitamin E, Rosehip Oil, Peptides',
    usageInstructions: 'Apply to clean face and neck twice daily, morning and evening. Gently massage until fully absorbed. Use sunscreen during the day when using this product. Suitable for all skin types.',
    benefits: 'Deeply hydrates and nourishes skin\nMay help reduce appearance of redness and irritation\nSupports natural skin barrier function\nAnti-aging properties from vitamins and peptides\nSuitable for sensitive skin',
    stockQuantity: 20,
    isActive: true,
    featured: true,
    weight: '50ml',
    cbdContent: '200mg CBD',
    thcContent: '< 0.2%',
    labTestCertUrl: 'https://example.com/lab-cert-facial-cream.pdf',
  },
];

const seedArticles = [
  {
    title: 'Understanding CBD: A Comprehensive Beginner\'s Guide',
    slug: 'understanding-cbd-beginners-guide',
    excerpt: 'Learn the basics of CBD, how it works in your body, and what to expect when starting your wellness journey with our comprehensive guide.',
    content: `# Understanding CBD: A Comprehensive Beginner's Guide

Cannabidiol, commonly known as CBD, has gained significant attention in the wellness community for its potential therapeutic benefits. As a natural compound found in hemp plants, CBD offers a non-intoxicating way to support your overall wellbeing.

## What is CBD?

CBD is one of over 100 cannabinoids found in the Cannabis sativa plant. Unlike THC (tetrahydrocannabinol), CBD does not produce psychoactive effects, meaning it won't make you feel "high." In the UK, CBD products must contain less than 0.2% THC to be legally sold.

## How Does CBD Work?

CBD interacts with your body's endocannabinoid system (ECS), a complex network of receptors that helps regulate various bodily functions including:

- Sleep cycles
- Mood regulation
- Pain perception
- Immune system response
- Stress management

## Getting Started with CBD

When beginning your CBD journey, it's important to:

1. **Start Low and Go Slow**: Begin with a small amount and gradually increase as needed
2. **Be Consistent**: Regular use often provides better results than sporadic dosing
3. **Track Your Experience**: Keep a journal to monitor how you feel
4. **Consult Healthcare Providers**: Especially if you have medical conditions or take medications

## Legal Status in the UK

All Leef products are fully compliant with UK regulations:
- Less than 0.2% THC content
- Derived from EU-approved hemp strains
- Third-party lab tested for purity and potency
- Registered with the Food Standards Agency

## Choosing Quality CBD Products

Look for products that offer:
- Third-party lab testing certificates
- Clear ingredient lists
- Proper labeling with CBD content
- Compliance with UK regulations
- Transparent company information

## Conclusion

CBD offers a natural approach to wellness support. By understanding how it works and choosing quality products, you can make informed decisions about incorporating CBD into your daily routine.

Remember: These statements have not been evaluated by the MHRA. CBD products are not intended to diagnose, treat, cure, or prevent any disease.`,
    imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400',
    imageAlt: 'Person practicing yoga outdoors in natural setting',
    category: 'education',
    tags: 'CBD, beginner, wellness, guide, UK, legal',
    published: true,
    readTime: 8,
  },
  {
    title: 'CBD Laws and Regulations in the United Kingdom',
    slug: 'cbd-laws-regulations-uk',
    excerpt: 'Everything you need to know about UK CBD regulations, compliance requirements, and what makes our products completely legal and safe.',
    content: `# CBD Laws and Regulations in the United Kingdom

Understanding the legal landscape of CBD in the UK is crucial for both consumers and businesses. This comprehensive guide covers everything you need to know about CBD regulations in the United Kingdom.

## Current Legal Status

CBD is legal in the UK when it meets specific criteria:

### THC Content Requirements
- Products must contain less than 0.2% THC
- This applies to the final product, not just the extract
- Regular testing ensures compliance

### Source Material
- CBD must be derived from EU-approved hemp strains
- Industrial hemp cultivation is regulated
- Only licensed producers can grow hemp in the UK

## Regulatory Bodies

### Food Standards Agency (FSA)
- Oversees CBD products intended for consumption
- Requires novel food applications for CBD products
- Sets safety standards and guidelines

### Medicines and Healthcare products Regulatory Agency (MHRA)
- Regulates medicinal CBD products
- Oversees prescription CBD medications
- Ensures pharmaceutical-grade standards

## Product Categories

### Food Supplements
- Most CBD oils, capsules, and edibles
- Must comply with FSA regulations
- Novel food authorization required

### Cosmetics and Topicals
- CBD balms, creams, and skincare products
- Regulated as cosmetic products
- Must meet safety requirements

### Medicinal Products
- Prescription-only medicines
- Require MHRA approval
- Available through licensed healthcare providers

## Consumer Rights and Safety

### What to Look For
- Third-party lab testing certificates
- Clear labeling with CBD and THC content
- Compliance certificates
- Company registration details

### Red Flags
- Products claiming to cure diseases
- Unclear or missing lab results
- Excessive THC content
- Unlicensed sellers

## Leef's Compliance Commitment

At Leef, we ensure full compliance by:

1. **Rigorous Testing**: Every batch is third-party tested
2. **Transparent Labeling**: Clear information on all packaging
3. **Legal Sourcing**: EU-approved hemp strains only
4. **Regular Audits**: Ongoing compliance monitoring
5. **Documentation**: Complete chain of custody records

## Future Developments

The UK CBD market continues to evolve:
- Ongoing FSA reviews of novel food applications
- Potential changes to advertising regulations
- Continued research into CBD benefits
- International harmonization efforts

## Conclusion

The UK has established a comprehensive regulatory framework for CBD products. By choosing compliant products from reputable companies like Leef, consumers can enjoy CBD benefits with confidence in safety and legality.

Stay informed about regulatory changes and always purchase from licensed, compliant suppliers.`,
    imageUrl: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400',
    imageAlt: 'UK legal documents and CBD regulation paperwork',
    category: 'education',
    tags: 'regulation, UK, legal, compliance, FSA, MHRA',
    published: true,
    readTime: 6,
  },
  {
    title: 'Incorporating CBD into Your Daily Skincare Routine',
    slug: 'cbd-skincare-routine',
    excerpt: 'Discover how CBD can enhance your daily skincare regimen for healthier, more balanced skin with our expert tips and product recommendations.',
    content: `# Incorporating CBD into Your Daily Skincare Routine

CBD has emerged as a powerful ingredient in skincare, offering potential benefits for various skin concerns. Learn how to effectively integrate CBD products into your daily routine for optimal results.

## Understanding CBD for Skincare

### How CBD Benefits Skin
- **Anti-inflammatory properties**: May help reduce redness and irritation
- **Antioxidant effects**: Protects against environmental stressors
- **Sebum regulation**: May help balance oil production
- **Soothing properties**: Calms sensitive skin

### Scientific Research
Recent studies suggest CBD may benefit:
- Acne-prone skin
- Sensitive or reactive skin
- Signs of aging
- Dry or dehydrated skin
- Inflammatory skin conditions

## Building Your CBD Skincare Routine

### Morning Routine

1. **Cleanse**: Start with a gentle cleanser
2. **Tone**: Apply alcohol-free toner
3. **CBD Serum**: Apply CBD-infused serum to clean skin
4. **Moisturize**: Use our CBD Facial Cream
5. **Sun Protection**: Always finish with SPF

### Evening Routine

1. **Double Cleanse**: Remove makeup and impurities
2. **Exfoliate**: 2-3 times per week
3. **Treatment**: Apply CBD products to clean skin
4. **Night Moisturizer**: CBD Facial Cream for overnight repair
5. **Eye Care**: CBD eye cream if needed

## Choosing the Right CBD Skincare

### Key Considerations
- **CBD Concentration**: Start with lower concentrations
- **Product Format**: Creams, serums, or balms
- **Additional Ingredients**: Look for complementary compounds
- **Skin Type**: Choose products formulated for your needs

### Ingredient Synergies
CBD works well with:
- Hyaluronic acid for hydration
- Vitamin C for antioxidant protection
- Niacinamide for pore refinement
- Peptides for anti-aging benefits

## Leef CBD Facial Cream Benefits

Our premium facial cream combines:
- **200mg CBD**: Optimal concentration for daily use
- **Hyaluronic Acid**: Deep hydration
- **Natural Botanicals**: Chamomile and aloe vera
- **Vitamins C & E**: Antioxidant protection
- **Lightweight Formula**: Suitable for all skin types

## Application Tips

### Best Practices
1. **Start Slowly**: Introduce CBD gradually
2. **Patch Test**: Test new products first
3. **Consistent Use**: Daily application for best results
4. **Layer Properly**: Thinnest to thickest consistency
5. **Sun Protection**: CBD can increase photosensitivity

### Common Mistakes
- Using too much product initially
- Skipping patch tests
- Inconsistent application
- Mixing with incompatible ingredients
- Expecting immediate results

## Expected Results Timeline

### Week 1-2
- Initial skin adjustment
- Possible mild reactions (normal)
- Begin to notice calming effects

### Week 3-4
- Reduced redness and irritation
- Improved skin texture
- Better hydration levels

### Month 2-3
- Visible improvement in skin clarity
- Enhanced overall skin health
- Optimized routine established

## Combining with Other Treatments

### Safe Combinations
- Gentle acids (lactic, mandelic)
- Vitamin C (morning use)
- Retinol (evening, separate from CBD)
- Hydrating ingredients

### Avoid Mixing With
- High concentrations of acids
- Strong actives simultaneously
- Alcohol-based products
- Harsh physical exfoliants

## Conclusion

CBD can be a valuable addition to your skincare routine when used correctly. Start slowly, be consistent, and choose high-quality products like Leef's CBD Facial Cream for the best results.

Remember that skincare is highly individual, and what works for others may need adjustment for your unique skin needs.`,
    imageUrl: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400',
    imageAlt: 'Natural skincare routine with CBD products and botanicals',
    category: 'lifestyle',
    tags: 'skincare, beauty, routine, CBD, facial cream',
    published: true,
    readTime: 7,
  },
];

async function seedDatabase() {
  try {
    console.log('Starting database seeding...');

    // Clear existing data
    await db.delete(articles);
    await db.delete(products);
    console.log('Cleared existing data');

    // Insert products
    for (const product of seedProducts) {
      await db.insert(products).values(product);
      console.log(`Inserted product: ${product.name}`);
    }

    // Insert articles
    for (const article of seedArticles) {
      await db.insert(articles).values(article);
      console.log(`Inserted article: ${article.title}`);
    }

    console.log('Database seeding completed successfully!');
    console.log(`Inserted ${seedProducts.length} products and ${seedArticles.length} articles`);

  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}

// Run the seed function if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log('Seeding completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Seeding failed:', error);
      process.exit(1);
    });
}

export { seedDatabase };
