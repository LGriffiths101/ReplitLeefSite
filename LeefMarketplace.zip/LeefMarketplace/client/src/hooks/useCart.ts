import { useState, useEffect } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { CartItem, OrderSummary } from '@/lib/types';
import { Product } from '@shared/schema';

const VAT_RATE = 0.2; // 20% UK VAT
const FREE_SHIPPING_THRESHOLD = 30;
const SHIPPING_COST = 4.99;

export function useCart() {
  const [cartItems, setCartItems] = useLocalStorage<CartItem[]>('leef_cart', []);
  const [isOpen, setIsOpen] = useState(false);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      
      if (existingItem) {
        const newQuantity = Math.min(existingItem.quantity + quantity, product.stockQuantity || 0);
        return prevItems.map(item =>
          item.id === product.id 
            ? { ...item, quantity: newQuantity }
            : item
        );
      } else {
        const newItem: CartItem = {
          id: product.id,
          name: product.name,
          price: parseFloat(product.price),
          imageUrl: product.imageUrl,
          quantity: Math.min(quantity, product.stockQuantity || 0),
          maxQuantity: product.stockQuantity || 0,
          slug: product.slug,
        };
        return [...prevItems, newItem];
      }
    });
  };

  const removeFromCart = (productId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === productId 
          ? { ...item, quantity: Math.min(quantity, item.maxQuantity) }
          : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getOrderSummary = (): OrderSummary => {
    const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
    const vatAmount = subtotal * VAT_RATE;
    const shippingAmount = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
    const total = subtotal + shippingAmount;
    const itemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

    return {
      subtotal: parseFloat(subtotal.toFixed(2)),
      vatAmount: parseFloat(vatAmount.toFixed(2)),
      shippingAmount: parseFloat(shippingAmount.toFixed(2)),
      total: parseFloat(total.toFixed(2)),
      itemCount,
    };
  };

  const openCart = () => setIsOpen(true);
  const closeCart = () => setIsOpen(false);

  return {
    items: cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getOrderSummary,
    isOpen,
    openCart,
    closeCart,
  };
}
