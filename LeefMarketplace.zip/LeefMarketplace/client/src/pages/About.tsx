import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Shield,
  Leaf,
  Award,
  Heart,
  Users,
  Target,
  CheckCircle,
  ArrowRight,
  Globe,
  Microscope,
  Truck,
  Phone
} from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Leaf,
      title: 'Natural',
      description: 'Pure ingredients sourced from EU-approved hemp farms',
      details: 'We believe in the power of nature. Our CBD is extracted using CO2 methods to preserve purity.'
    },
    {
      icon: Shield,
      title: 'Certified',
      description: 'UK compliant with all MHRA regulations',
      details: 'Every product meets strict UK standards with less than 0.2% THC content.'
    },
    {
      icon: Microscope,
      title: 'Tested',
      description: 'Third-party lab verified for quality and safety',
      details: 'Independent testing ensures potency, purity, and peace of mind for our customers.'
    },
    {
      icon: Heart,
      title: 'Caring',
      description: 'Dedicated to your wellness journey',
      details: 'We care about your health and wellbeing, providing support every step of the way.'
    },
  ];

  const milestones = [
    {
      year: '2020',
      title: 'Company Founded',
      description: 'Leef was established with a mission to provide premium CBD wellness products to the UK market.'
    },
    {
      year: '2021',
      title: 'MHRA Compliance',
      description: 'Achieved full compliance with UK MHRA regulations and obtained necessary certifications.'
    },
    {
      year: '2022',
      title: 'Product Launch',
      description: 'Launched our first three products: Massage Balm, Roll On Active Balm, and Facial Cream.'
    },
    {
      year: '2023',
      title: 'Expansion',
      description: 'Expanded distribution across the UK and built partnerships with trusted suppliers.'
    },
    {
      year: '2024',
      title: 'Innovation',
      description: 'Continued innovation in CBD wellness with new formulations and sustainable packaging.'
    },
  ];

  const team = [
    {
      name: 'Sarah Johnson',
      role: 'Founder & CEO',
      description: 'Background in natural health and wellness with 15+ years experience in the industry.',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400'
    },
    {
      name: 'Dr. Michael Chen',
      role: 'Head of Product Development',
      description: 'PhD in Biochemistry with expertise in natural compound extraction and formulation.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400'
    },
    {
      name: 'Emma Williams',
      role: 'Quality Assurance Manager',
      description: 'Ensures all products meet the highest standards of quality, safety, and compliance.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400'
    },
  ];

  const commitments = [
    'Sustainably sourced ingredients',
    'Cruelty-free and vegan products',
    'Transparent supply chain',
    'Third-party lab testing',
    'GDPR compliant data protection',
    'Carbon-neutral shipping',
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/5 to-primary-light/5 py-16 lg:py-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1559181567-c3190ca9959b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')] bg-cover bg-center opacity-10" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20">
              About Leef
            </Badge>
            
            <h1 className="text-4xl lg:text-6xl font-serif font-bold text-gray-900 mb-6">
              Committed to Your{' '}
              <span className="text-primary">Natural Wellbeing</span>
            </h1>
            
            <p className="text-lg lg:text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              At Leef, we believe in the power of nature to heal and restore. Our premium CBD products are 
              carefully crafted using only the finest natural ingredients, sourced ethically and processed with the utmost care.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/shop">
                <Button size="lg" className="bg-primary hover:bg-primary-light">
                  Shop Our Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" size="lg" className="border-2 border-primary text-primary hover:bg-primary hover:text-white">
                  Get in Touch
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-8">
              Our Mission
            </h2>
            <p className="text-xl text-gray-600 leading-relaxed mb-12">
              To provide the highest quality CBD wellness products that support natural health and wellbeing, 
              while maintaining complete transparency, sustainability, and compliance with UK regulations. 
              We're committed to empowering individuals on their wellness journey through the therapeutic benefits of premium CBD.
            </p>
            
            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">100%</div>
                <div className="text-sm text-gray-600">Natural Ingredients</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">3</div>
                <div className="text-sm text-gray-600">Premium Products</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">5+</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">1000+</div>
                <div className="text-sm text-gray-600">Happy Customers</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These core principles guide everything we do, from sourcing ingredients to supporting our customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                    <p className="text-gray-600 mb-3">{value.description}</p>
                    <p className="text-sm text-gray-500">{value.details}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Our Story Timeline */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From humble beginnings to becoming a trusted CBD wellness brand in the UK.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-8 top-8 bottom-8 w-0.5 bg-primary/20"></div>
              
              <div className="space-y-8">
                {milestones.map((milestone, index) => (
                  <div key={index} className="relative flex items-start gap-6">
                    <div className="flex-shrink-0 w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                      {milestone.year}
                    </div>
                    <div className="flex-1 bg-white rounded-lg shadow-sm border p-6">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              The passionate people behind Leef, dedicated to bringing you the best in CBD wellness.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {team.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-primary font-medium mb-3">{member.role}</p>
                  <p className="text-sm text-gray-600">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Commitments */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-6">
                  Our Commitments
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  We hold ourselves to the highest standards in everything we do. Our commitments 
                  reflect our dedication to quality, sustainability, and ethical business practices.
                </p>

                <div className="grid grid-cols-1 gap-4">
                  {commitments.map((commitment, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{commitment}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-8">
                  <Link href="/contact">
                    <Button className="bg-primary hover:bg-primary-light">
                      Learn More About Our Practices
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1559181567-c3190ca9959b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="CBD lab testing and quality assurance"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
                
                {/* Certification badges */}
                <div className="absolute bottom-4 left-4 right-4 bg-white rounded-lg p-4 shadow-lg">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <Shield className="h-6 w-6 text-primary mx-auto mb-1" />
                      <div className="text-xs font-medium">UK Compliant</div>
                    </div>
                    <div className="text-center">
                      <Award className="h-6 w-6 text-primary mx-auto mb-1" />
                      <div className="text-xs font-medium">Lab Tested</div>
                    </div>
                    <div className="text-center">
                      <Leaf className="h-6 w-6 text-primary mx-auto mb-1" />
                      <div className="text-xs font-medium">Natural</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 lg:py-24 bg-gradient-to-r from-primary to-primary-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold mb-6">
              Ready to Start Your Wellness Journey?
            </h2>
            <p className="text-lg mb-8 text-white/90">
              Discover how our premium CBD products can support your natural wellbeing. 
              Our team is here to help you every step of the way.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/shop">
                <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-gray-100">
                  Shop Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  <Phone className="mr-2 h-5 w-5" />
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
