import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ProductCard } from '@/components/ProductCard';
import { 
  ArrowRight, 
  Leaf, 
  Shield, 
  Award, 
  Heart, 
  Truck, 
  Users,
  Star,
  CheckCircle
} from 'lucide-react';
import { Product } from '@shared/schema';

export default function Home() {
  const { data: featuredProducts, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products?featured=true'],
  });

  const trustIndicators = [
    { icon: Shield, label: 'UK Compliant', description: '< 0.2% THC' },
    { icon: Leaf, label: 'Natural Ingredients', description: '100% Organic' },
    { icon: Award, label: 'Lab Tested', description: 'Third-party verified' },
    { icon: Truck, label: 'Free UK Delivery', description: 'Orders over £30' },
  ];

  const benefits = [
    'Premium CBD from EU-approved hemp',
    'CO2 extraction for purity',
    'Third-party lab tested',
    'UK MHRA compliant',
    'Vegan and cruelty-free',
    '30-day money-back guarantee',
  ];

  const testimonials = [
    {
      name: 'Sarah M.',
      location: 'London',
      rating: 5,
      text: 'The massage balm has been a game-changer for my post-workout recovery. Natural, effective, and I love that it\'s UK-made.',
    },
    {
      name: 'James T.',
      location: 'Manchester',
      rating: 5,
      text: 'Excellent quality products. The roll-on is perfect for on-the-go relief. Fast delivery and great customer service.',
    },
    {
      name: 'Emma K.',
      location: 'Edinburgh',
      rating: 5,
      text: 'The facial cream has transformed my skincare routine. My skin feels more balanced and healthy. Highly recommend!',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/5 to-primary-light/5 py-16 lg:py-24 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1515377905703-c4788e51af15?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')] bg-cover bg-center opacity-15" />
        <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-transparent to-white/30" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 animate-fade-in">
              Trusted Since 2020
            </Badge>
            
            <h1 className="text-4xl lg:text-6xl font-sans font-bold text-gray-900 mb-6 animate-fade-in">
              Elevate Your{' '}
              <span className="text-primary">
                Daily Routine
              </span>
            </h1>
            
            <p className="text-lg lg:text-xl text-gray-600 mb-8 max-w-2xl mx-auto animate-fade-in">
              Experience the perfect blend of nature and science with our premium collection. 
              Thoughtfully crafted, rigorously tested, and designed for the modern lifestyle.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link href="/shop">
                <Button size="lg" className="bg-primary hover:bg-primary-light text-lg px-8 py-4">
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/about">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-2 border-primary text-primary hover:bg-primary hover:text-white text-lg px-8 py-4"
                >
                  Learn More
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {trustIndicators.map((indicator, index) => {
                const IconComponent = indicator.icon;
                return (
                  <div key={index} className="text-center">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-3">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">{indicator.label}</h3>
                    <p className="text-sm text-gray-600">{indicator.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-sans font-bold text-gray-900 mb-4">
              Discover Our Collection
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Premium formulations designed to seamlessly integrate into your daily routine.
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 aspect-square rounded-t-lg" />
                  <div className="bg-white p-6 rounded-b-lg border border-t-0">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-4" />
                    <div className="h-8 bg-gray-200 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : featuredProducts && featuredProducts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto mb-12">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} featured />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No featured products available.</p>
            </div>
          )}

          <div className="text-center">
            <Link href="/shop">
              <Button variant="outline" size="lg" className="border-2 border-primary text-primary hover:bg-primary hover:text-white">
                View All Products
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
            <div>
              <h2 className="text-3xl lg:text-4xl font-sans font-bold text-gray-900 mb-6">
                Where Science Meets{' '}
                <span className="text-primary">Nature</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Our research-driven approach combines cutting-edge extraction methods with time-tested 
                botanical knowledge. Each formula is precisely calibrated for maximum effectiveness.
              </p>
              <p className="text-gray-600 mb-8">
                From lab to lifestyle, we ensure every product meets the highest standards of 
                purity, potency, and performance through rigorous third-party testing.
              </p>

              <div className="grid grid-cols-2 gap-4 mb-8">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{benefit}</span>
                  </div>
                ))}
              </div>

              <Link href="/about">
                <Button className="bg-primary hover:bg-primary-light">
                  Our Story
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>

            <div className="relative group">
              <img
                src="https://images.unsplash.com/photo-1596755389378-c31d21fd1273?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                alt="Premium natural skincare products with botanical ingredients"
                className="rounded-xl shadow-lg w-full h-auto transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-4 shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                <div className="flex items-center gap-2">
                  <Shield className="h-6 w-6 text-primary" />
                  <div>
                    <div className="font-semibold text-sm">Lab Verified</div>
                    <div className="text-xs text-gray-600">Third-party tested</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="py-16 lg:py-24 bg-gradient-to-br from-primary/5 to-neutral-light">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-sans font-bold text-gray-900 mb-4">
              Trusted by Thousands
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Join the growing community of customers who've made Leef part of their daily routine.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-500">{testimonial.location}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto bg-gradient-to-r from-primary to-primary-light text-white">
            <CardContent className="p-8 text-center">
              <Heart className="h-12 w-12 mx-auto mb-4 text-white/80" />
              <h3 className="text-2xl font-sans font-bold mb-4">
                Join Our Community
              </h3>
              <p className="mb-6 text-white/90">
                Be the first to discover new products, exclusive offers, and expert insights.
              </p>
              <Link href="/contact">
                <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100">
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
