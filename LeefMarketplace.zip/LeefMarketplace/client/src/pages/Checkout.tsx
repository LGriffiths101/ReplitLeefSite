import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link, useLocation } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import { CheckoutFormData, OrderSummary, UK_COUNTIES } from '@/lib/types';

// Load Stripe
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  ShoppingCart,
  CreditCard,
  Shield,
  Truck,
  CheckCircle,
  ArrowLeft,
  Lock,
  Package,
  AlertTriangle,
  Heart
} from 'lucide-react';

const checkoutSchema = z.object({
  // Billing Information
  billingFirstName: z.string().min(1, 'First name is required'),
  billingLastName: z.string().min(1, 'Last name is required'),
  billingEmail: z.string().email('Please enter a valid email address'),
  billingPhone: z.string().min(10, 'Please enter a valid phone number'),
  billingAddress1: z.string().min(1, 'Address is required'),
  billingAddress2: z.string().optional(),
  billingCity: z.string().min(1, 'City is required'),
  billingCounty: z.string().optional(),
  billingPostcode: z.string().min(1, 'Postcode is required'),
  billingCountry: z.string().default('United Kingdom'),
  
  // Shipping Information
  shippingFirstName: z.string().min(1, 'First name is required'),
  shippingLastName: z.string().min(1, 'Last name is required'),
  shippingAddress1: z.string().min(1, 'Address is required'),
  shippingAddress2: z.string().optional(),
  shippingCity: z.string().min(1, 'City is required'),
  shippingCounty: z.string().optional(),
  shippingPostcode: z.string().min(1, 'Postcode is required'),
  shippingCountry: z.string().default('United Kingdom'),
  
  // Options
  sameAsShipping: z.boolean().default(false),
  agreeToTerms: z.boolean().refine((val) => val === true, {
    message: 'You must agree to the terms and conditions',
  }),
  marketingConsent: z.boolean().default(false),
  notes: z.string().optional(),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const { items, getOrderSummary, clearCart } = useCart();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState<string>('');

  const orderSummary = getOrderSummary();

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      billingFirstName: '',
      billingLastName: '',
      billingEmail: '',
      billingPhone: '',
      billingAddress1: '',
      billingAddress2: '',
      billingCity: '',
      billingCounty: '',
      billingPostcode: '',
      billingCountry: 'United Kingdom',
      shippingFirstName: '',
      shippingLastName: '',
      shippingAddress1: '',
      shippingAddress2: '',
      shippingCity: '',
      shippingCounty: '',
      shippingPostcode: '',
      shippingCountry: 'United Kingdom',
      sameAsShipping: false,
      agreeToTerms: false,
      marketingConsent: false,
      notes: '',
    },
  });

  const watchSameAsShipping = form.watch('sameAsShipping');

  // Copy billing to shipping when sameAsShipping is checked
  useEffect(() => {
    if (watchSameAsShipping) {
      const billingData = form.getValues();
      form.setValue('shippingFirstName', billingData.billingFirstName);
      form.setValue('shippingLastName', billingData.billingLastName);
      form.setValue('shippingAddress1', billingData.billingAddress1);
      form.setValue('shippingAddress2', billingData.billingAddress2 || '');
      form.setValue('shippingCity', billingData.billingCity);
      form.setValue('shippingCounty', billingData.billingCounty || '');
      form.setValue('shippingPostcode', billingData.billingPostcode);
      form.setValue('shippingCountry', billingData.billingCountry);
    }
  }, [watchSameAsShipping, form]);

  const orderMutation = useMutation({
    mutationFn: async (data: CheckoutFormValues) => {
      // Prepare order data
      const orderData = {
        subtotal: orderSummary.subtotal.toString(),
        vatAmount: orderSummary.vatAmount.toString(),
        shippingAmount: orderSummary.shippingAmount.toString(),
        total: orderSummary.total.toString(),
        currency: 'GBP',
        paymentStatus: 'pending',
        paymentMethod: 'stripe',
        
        // Billing information
        billingFirstName: data.billingFirstName,
        billingLastName: data.billingLastName,
        billingEmail: data.billingEmail,
        billingPhone: data.billingPhone,
        billingAddress1: data.billingAddress1,
        billingAddress2: data.billingAddress2 || '',
        billingCity: data.billingCity,
        billingCounty: data.billingCounty || '',
        billingPostcode: data.billingPostcode,
        billingCountry: data.billingCountry,
        
        // Shipping information
        shippingFirstName: data.shippingFirstName,
        shippingLastName: data.shippingLastName,
        shippingAddress1: data.shippingAddress1,
        shippingAddress2: data.shippingAddress2 || '',
        shippingCity: data.shippingCity,
        shippingCounty: data.shippingCounty || '',
        shippingPostcode: data.shippingPostcode,
        shippingCountry: data.shippingCountry,
        
        notes: data.notes || '',
        
        // Order items
        orderItems: items.map(item => ({
          productId: item.id,
          quantity: item.quantity,
          unitPrice: item.price.toString(),
          totalPrice: (item.price * item.quantity).toString(),
          productName: item.name,
          productDescription: `${item.name} - ${item.quantity} x ${item.price}`,
        })),
      };

      return apiRequest('POST', '/api/orders', orderData);
    },
    onSuccess: (response) => {
      const data = response.data || {};
      setOrderNumber(data.order?.orderNumber || 'UNKNOWN');
      setOrderComplete(true);
      clearCart();
      toast({
        title: "Order placed successfully!",
        description: "Thank you for your purchase. You'll receive a confirmation email shortly.",
      });
    },
    onError: (error: any) => {
      console.error('Order creation failed:', error);
      toast({
        title: "Order failed",
        description: "There was an error processing your order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: CheckoutFormValues) => {
    setIsProcessing(true);
    
    try {
      // In a real implementation, you would integrate with Stripe here
      // For now, we'll simulate the payment process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      orderMutation.mutate(data);
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
    }).format(price);
  };

  // Redirect if cart is empty and order not complete
  if (items.length === 0 && !orderComplete) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-4">
              Add some products to your cart before proceeding to checkout.
            </p>
            <Link href="/shop">
              <Button className="bg-primary hover:bg-primary-light">
                Continue Shopping
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Order completion screen
  if (orderComplete) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto">
          <CardContent className="pt-6 text-center">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            
            <h1 className="text-3xl font-serif font-bold text-gray-900 mb-4">
              Order Confirmed!
            </h1>
            
            <p className="text-lg text-gray-600 mb-6">
              Thank you for your purchase. Your order has been received and is being processed.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="font-medium">Order Number:</span>
                <span className="font-mono text-primary">{orderNumber}</span>
              </div>
              <div className="flex items-center justify-between mb-4">
                <span className="font-medium">Total:</span>
                <span className="text-xl font-bold">{formatPrice(orderSummary.total)}</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
                <Truck className="h-4 w-4" />
                <span>Expected delivery: 2-3 business days</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <p className="text-sm text-gray-600">
                A confirmation email has been sent to your email address with order details and tracking information.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link href="/shop">
                  <Button className="bg-primary hover:bg-primary-light">
                    Continue Shopping
                  </Button>
                </Link>
                <Link href="/">
                  <Button variant="outline">
                    Back to Home
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/shop">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Shop
            </Button>
          </Link>
          
          <h1 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
            Secure Checkout
          </h1>
          
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Shield className="h-4 w-4 text-green-600" />
            <span>SSL Secured • Your information is protected</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Age Verification Notice */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-amber-800 mb-1">Age Verification Required</p>
                    <p className="text-amber-700">
                      By proceeding with this purchase, you confirm that you are 18 years or older and 
                      eligible to purchase CBD products in the UK.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Billing Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Billing Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="billingFirstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter first name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="billingLastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="billingEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address *</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="Enter email address" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="billingPhone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number *</FormLabel>
                            <FormControl>
                              <Input type="tel" placeholder="Enter phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="billingAddress1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address Line 1 *</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter street address" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="billingAddress2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address Line 2</FormLabel>
                          <FormControl>
                            <Input placeholder="Apartment, suite, etc. (optional)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="billingCity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter city" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="billingCounty"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>County</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select county" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {UK_COUNTIES.map((county) => (
                                  <SelectItem key={county} value={county}>
                                    {county}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="billingPostcode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Postcode *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter postcode" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Shipping Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      Shipping Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="sameAsShipping"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Same as billing address
                            </FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />

                    {!watchSameAsShipping && (
                      <>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="shippingFirstName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>First Name *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter first name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="shippingLastName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Last Name *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter last name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="shippingAddress1"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address Line 1 *</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter street address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="shippingAddress2"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address Line 2</FormLabel>
                              <FormControl>
                                <Input placeholder="Apartment, suite, etc. (optional)" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <FormField
                            control={form.control}
                            name="shippingCity"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>City *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter city" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="shippingCounty"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>County</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select county" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {UK_COUNTIES.map((county) => (
                                      <SelectItem key={county} value={county}>
                                        {county}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="shippingPostcode"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Postcode *</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter postcode" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>

                {/* Order Notes */}
                <Card>
                  <CardHeader>
                    <CardTitle>Order Notes (Optional)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Textarea
                              placeholder="Any special instructions for your order..."
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Terms and Marketing */}
                <Card>
                  <CardContent className="pt-6 space-y-4">
                    <FormField
                      control={form.control}
                      name="agreeToTerms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              I agree to the{' '}
                              <a href="/terms" className="text-primary underline">
                                Terms & Conditions
                              </a>{' '}
                              and{' '}
                              <a href="/privacy" className="text-primary underline">
                                Privacy Policy
                              </a>{' '}
                              *
                            </FormLabel>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="marketingConsent"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              I would like to receive marketing emails about products and offers
                            </FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isProcessing || orderMutation.isPending}
                  className="w-full bg-primary hover:bg-primary-light text-lg py-6"
                >
                  {isProcessing || orderMutation.isPending ? (
                    'Processing Order...'
                  ) : (
                    <>
                      <Lock className="mr-2 h-5 w-5" />
                      Complete Secure Order
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Order Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Order Items */}
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <div className="w-16 h-16 bg-gray-100 rounded-lg flex-shrink-0 flex items-center justify-center">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.name}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          ) : (
                            <Package className="h-6 w-6 text-gray-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{item.name}</h4>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-sm text-gray-600">
                              Qty: {item.quantity}
                            </span>
                            <span className="font-medium">
                              {formatPrice(item.price * item.quantity)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Order Totals */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal:</span>
                      <span>{formatPrice(orderSummary.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>VAT (20%):</span>
                      <span>{formatPrice(orderSummary.vatAmount)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Shipping:</span>
                      <span>
                        {orderSummary.shippingAmount === 0 ? (
                          <span className="text-green-600 font-medium">FREE</span>
                        ) : (
                          formatPrice(orderSummary.shippingAmount)
                        )}
                      </span>
                    </div>
                    
                    {orderSummary.subtotal < 30 && orderSummary.shippingAmount > 0 && (
                      <div className="text-xs text-amber-600 bg-amber-50 rounded p-2">
                        Add {formatPrice(30 - orderSummary.subtotal)} more for free delivery
                      </div>
                    )}
                    
                    <Separator />
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Total:</span>
                      <span>{formatPrice(orderSummary.total)}</span>
                    </div>
                  </div>

                  {/* Trust Indicators */}
                  <div className="pt-4 space-y-3 border-t">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Shield className="h-4 w-4 text-green-600" />
                      <span>SSL encrypted checkout</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Truck className="h-4 w-4 text-blue-600" />
                      <span>2-3 day delivery</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Heart className="h-4 w-4 text-red-500" />
                      <span>30-day return policy</span>
                    </div>
                  </div>

                  {/* Payment Methods */}
                  <div className="pt-4 border-t">
                    <p className="text-sm text-gray-600 mb-2">We accept:</p>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">Visa</Badge>
                      <Badge variant="outline" className="text-xs">Mastercard</Badge>
                      <Badge variant="outline" className="text-xs">PayPal</Badge>
                      <Badge variant="outline" className="text-xs">Apple Pay</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
