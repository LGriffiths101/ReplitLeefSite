import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { FAQ } from '@/components/FAQ';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  BookOpen,
  Clock,
  ArrowRight,
  Mail,
  Heart,
  Leaf,
  Shield,
  Users,
  Lightbulb,
  Target,
  Award
} from 'lucide-react';
import { Article, insertNewsletterSubscriptionSchema } from '@shared/schema';

const newsletterSchema = insertNewsletterSubscriptionSchema;
type NewsletterFormData = z.infer<typeof newsletterSchema>;

export default function Wellness() {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const form = useForm<NewsletterFormData>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: {
      email: '',
    },
  });

  const { data: articles, isLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
  });

  const newsletterMutation = useMutation({
    mutationFn: async (data: NewsletterFormData) => {
      return apiRequest('POST', '/api/newsletter/subscribe', data);
    },
    onSuccess: () => {
      toast({
        title: "Successfully subscribed!",
        description: "Thank you for joining our wellness community.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onNewsletterSubmit = (data: NewsletterFormData) => {
    newsletterMutation.mutate(data);
  };

  const categories = [
    { value: 'all', label: 'All Articles' },
    { value: 'education', label: 'Education' },
    { value: 'wellness', label: 'Wellness Tips' },
    { value: 'research', label: 'Research' },
    { value: 'lifestyle', label: 'Lifestyle' },
  ];

  const wellnessTips = [
    {
      icon: Heart,
      title: 'Start Small',
      description: 'Begin with small amounts and gradually adjust based on your body\'s response.'
    },
    {
      icon: Clock,
      title: 'Be Consistent',
      description: 'Regular use often provides better results than sporadic large doses.'
    },
    {
      icon: Target,
      title: 'Track Your Progress',
      description: 'Keep a wellness journal to monitor how you feel and adjust accordingly.'
    },
    {
      icon: Users,
      title: 'Consult Professionals',
      description: 'Always speak with healthcare providers, especially if you have medical conditions.'
    },
  ];

  const benefits = [
    {
      title: 'Natural Wellness Support',
      description: 'CBD may support your natural wellness routine as part of a healthy lifestyle.',
      icon: Leaf
    },
    {
      title: 'Quality You Can Trust',
      description: 'All our products are third-party tested and UK-compliant for your peace of mind.',
      icon: Shield
    },
    {
      title: 'Educational Resources',
      description: 'Access to expert knowledge and guidance on CBD and wellness practices.',
      icon: BookOpen
    },
    {
      title: 'Community Support',
      description: 'Join a community of wellness enthusiasts on similar journeys.',
      icon: Users
    },
  ];

  // Mock articles if no data is available
  const mockArticles = [
    {
      id: 1,
      title: 'Understanding CBD: A Beginner\'s Guide',
      slug: 'understanding-cbd-beginners-guide',
      excerpt: 'Learn the basics of CBD, how it works, and what to expect when starting your wellness journey.',
      content: '',
      imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300',
      imageAlt: 'Person practicing yoga outdoors',
      category: 'education',
      tags: 'CBD, beginner, wellness',
      published: true,
      readTime: 5,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 2,
      title: 'CBD Laws and Regulations in the UK',
      slug: 'cbd-laws-regulations-uk',
      excerpt: 'Everything you need to know about UK CBD regulations, compliance, and what makes our products legal.',
      content: '',
      imageUrl: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300',
      imageAlt: 'UK legal documents and CBD regulations',
      category: 'education',
      tags: 'regulation, UK, legal',
      published: true,
      readTime: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 3,
      title: 'Incorporating CBD into Your Skincare Routine',
      slug: 'cbd-skincare-routine',
      excerpt: 'Discover how CBD can enhance your daily skincare regimen for healthier, more balanced skin.',
      content: '',
      imageUrl: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300',
      imageAlt: 'Natural skincare routine with CBD products',
      category: 'lifestyle',
      tags: 'skincare, beauty, routine',
      published: true,
      readTime: 4,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];

  const displayArticles = articles || mockArticles;
  const filteredArticles = selectedCategory === 'all' 
    ? displayArticles 
    : displayArticles.filter(article => article.category === selectedCategory);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'education':
        return 'bg-blue-100 text-blue-800';
      case 'wellness':
        return 'bg-green-100 text-green-800';
      case 'research':
        return 'bg-purple-100 text-purple-800';
      case 'lifestyle':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/5 to-primary-light/5 py-16 lg:py-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')] bg-cover bg-center opacity-10" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20">
              Wellness & Education
            </Badge>
            
            <h1 className="text-4xl lg:text-6xl font-serif font-bold text-gray-900 mb-6">
              Your Journey to{' '}
              <span className="text-primary">Natural Wellness</span>
            </h1>
            
            <p className="text-lg lg:text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Discover the science behind CBD, learn best practices, and get expert guidance 
              on incorporating natural wellness into your daily routine.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary-light">
                <BookOpen className="mr-2 h-5 w-5" />
                Explore Articles
              </Button>
              <Link href="/shop">
                <Button variant="outline" size="lg" className="border-2 border-primary text-primary hover:bg-primary hover:text-white">
                  Shop Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Why Choose Natural Wellness?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover the benefits of incorporating CBD into your wellness routine with expert guidance and quality products.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                    <p className="text-gray-600 text-sm">{benefit.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Articles Section */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Wellness Articles & Guides
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Learn from experts and stay informed about CBD benefits, usage tips, and wellness practices.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category.value
                    ? 'bg-primary text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>

          {/* Articles Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 aspect-video rounded-t-lg" />
                  <div className="bg-white p-6 rounded-b-lg border border-t-0">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-4" />
                    <div className="h-8 bg-gray-200 rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredArticles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
              {filteredArticles.map((article) => (
                <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-gray-100">
                    {article.imageUrl ? (
                      <img
                        src={article.imageUrl}
                        alt={article.imageAlt || article.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <BookOpen className="h-12 w-12 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <Badge variant="secondary" className={getCategoryColor(article.category)}>
                        {article.category}
                      </Badge>
                      {article.readTime && (
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <Clock className="h-4 w-4" />
                          <span>{article.readTime} min read</span>
                        </div>
                      )}
                    </div>
                    
                    <h3 className="text-xl font-semibold text-gray-900 mb-3 line-clamp-2">
                      {article.title}
                    </h3>
                    
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {article.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {new Date(article.createdAt!).toLocaleDateString()}
                      </span>
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary-light">
                        Read More →
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
              <p className="text-gray-500">No articles available for the selected category.</p>
            </div>
          )}
        </div>
      </section>

      {/* Wellness Tips */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Getting Started with CBD
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Essential tips for beginners to make the most of their CBD wellness journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto mb-12">
            {wellnessTips.map((tip, index) => {
              const IconComponent = tip.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{tip.title}</h3>
                  <p className="text-gray-600 text-sm">{tip.description}</p>
                </div>
              );
            })}
          </div>

          <div className="text-center">
            <Link href="/contact">
              <Button variant="outline" size="lg" className="border-2 border-primary text-primary hover:bg-primary hover:text-white">
                Get Personalized Guidance
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Get answers to common questions about CBD products and UK regulations.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <FAQ />
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 lg:py-24 bg-gradient-to-r from-primary to-primary-light">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <Mail className="h-8 w-8 text-white" />
            </div>
            
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-white mb-6">
              Stay Informed & Empowered
            </h2>
            
            <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
              Join our wellness community and get exclusive tips, early access to new articles, 
              and special offers delivered to your inbox.
            </p>

            <Card className="max-w-md mx-auto">
              <CardContent className="p-6">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onNewsletterSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="Enter your email address"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button
                      type="submit"
                      disabled={newsletterMutation.isPending}
                      className="w-full bg-primary hover:bg-primary-light"
                    >
                      {newsletterMutation.isPending ? (
                        'Subscribing...'
                      ) : (
                        <>
                          <Heart className="mr-2 h-4 w-4" />
                          Join Our Community
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
                
                <p className="text-xs text-gray-500 mt-3 text-center">
                  We respect your privacy. Unsubscribe at any time.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
