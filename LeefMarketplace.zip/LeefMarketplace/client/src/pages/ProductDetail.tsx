import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/useCart';
import { apiRequest } from '@/lib/queryClient';
import {
  ShoppingCart,
  Plus,
  Minus,
  Star,
  Shield,
  Leaf,
  Truck,
  Award,
  ArrowLeft,
  Package,
  Heart,
  Share2,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { ProductWithReviews, InsertReview } from '@shared/schema';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedTab, setSelectedTab] = useState('description');
  const [reviewData, setReviewData] = useState({
    rating: 5,
    title: '',
    comment: '',
  });

  const { data: product, isLoading, error } = useQuery<ProductWithReviews>({
    queryKey: [`/api/products/slug/${slug}`],
    enabled: !!slug,
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: InsertReview) => {
      return apiRequest('POST', `/api/products/${product!.id}/reviews`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/products/slug/${slug}`] });
      setReviewData({ rating: 5, title: '', comment: '' });
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddToCart = () => {
    if (!product) return;
    
    if (product.stockQuantity === 0) {
      toast({
        title: "Out of stock",
        description: "This product is currently out of stock.",
        variant: "destructive",
      });
      return;
    }

    if (quantity > product.stockQuantity) {
      toast({
        title: "Insufficient stock",
        description: `Only ${product.stockQuantity} items available.`,
        variant: "destructive",
      });
      return;
    }

    addToCart(product, quantity);
    toast({
      title: "Added to cart",
      description: `${quantity} x ${product.name} added to your cart.`,
    });
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity < 1) return;
    if (product && newQuantity > product.stockQuantity) return;
    setQuantity(newQuantity);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !reviewData.comment.trim()) return;

    reviewMutation.mutate({
      productId: product.id,
      rating: reviewData.rating,
      title: reviewData.title.trim() || undefined,
      comment: reviewData.comment.trim(),
      userId: undefined, // Would be set if user was logged in
    });
  };

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
    }).format(parseFloat(price));
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'massage':
        return '💆';
      case 'active':
        return '🏃';
      case 'skincare':
        return '🌟';
      default:
        return '🌿';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'massage':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'skincare':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const tabs = [
    { id: 'description', label: 'Description' },
    { id: 'ingredients', label: 'Ingredients' },
    { id: 'usage', label: 'Usage' },
    { id: 'reviews', label: `Reviews (${product?.reviewCount || 0})` },
  ];

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="aspect-square bg-gray-200 rounded-lg" />
            <div className="space-y-4">
              <div className="h-8 bg-gray-200 rounded w-3/4" />
              <div className="h-6 bg-gray-200 rounded w-1/2" />
              <div className="h-12 bg-gray-200 rounded" />
              <div className="h-10 bg-gray-200 rounded w-1/3" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6 text-center">
            <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Product not found</h2>
            <p className="text-gray-600 mb-4">
              The product you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/shop">
              <Button>Back to Shop</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stockStatus = product.stockQuantity > 0 ? 'In Stock' : 'Out of Stock';
  const stockColor = product.stockQuantity > 0 ? 'text-green-600' : 'text-red-600';

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-gray-600 mb-8">
        <Link href="/" className="hover:text-primary">Home</Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-primary">Shop</Link>
        <span>/</span>
        <span className="text-gray-900">{product.name}</span>
      </nav>

      {/* Back Button */}
      <Link href="/shop">
        <Button variant="ghost" className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Shop
        </Button>
      </Link>

      {/* Product Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        {/* Product Image */}
        <div className="space-y-4">
          <div className="aspect-square bg-gray-50 rounded-lg overflow-hidden">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.imageAlt || product.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex items-center justify-center h-full">
                <Package className="h-24 w-24 text-gray-300" />
              </div>
            )}
          </div>
          
          {/* Trust Badges */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
              <Shield className="h-5 w-5 text-green-600" />
              <div>
                <div className="text-sm font-medium">UK Compliant</div>
                <div className="text-xs text-gray-600">{'< 0.2% THC'}</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
              <Award className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-sm font-medium">Lab Tested</div>
                <div className="text-xs text-gray-600">Third-party verified</div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          {/* Category & Rating */}
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className={getCategoryColor(product.category)}>
              <span className="mr-1">{getCategoryIcon(product.category)}</span>
              {product.category}
            </Badge>
            
            {product.averageRating && product.reviewCount > 0 && (
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.averageRating!)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">
                  {product.averageRating.toFixed(1)} ({product.reviewCount} reviews)
                </span>
              </div>
            )}
          </div>

          {/* Title & Price */}
          <div>
            <h1 className="text-3xl font-serif font-bold text-gray-900 mb-4">
              {product.name}
            </h1>
            
            <div className="flex items-baseline gap-4 mb-4">
              <div className="text-3xl font-bold text-primary">
                {formatPrice(product.price)}
              </div>
              <div className="text-sm text-gray-500">inc. VAT</div>
            </div>

            <div className={`text-sm font-medium ${stockColor} mb-4`}>
              {stockStatus}
              {product.stockQuantity > 0 && product.stockQuantity <= 5 && (
                <span className="text-amber-600 ml-2">
                  (Only {product.stockQuantity} left)
                </span>
              )}
            </div>
          </div>

          {/* Short Description */}
          <div className="text-gray-600">
            <p>{product.shortDescription || product.description}</p>
          </div>

          {/* Product Highlights */}
          <div className="space-y-2">
            {product.cbdContent && (
              <div className="flex items-center gap-2 text-sm">
                <Leaf className="h-4 w-4 text-green-600" />
                <span>CBD Content: <strong>{product.cbdContent}</strong></span>
              </div>
            )}
            {product.weight && (
              <div className="flex items-center gap-2 text-sm">
                <Package className="h-4 w-4 text-blue-600" />
                <span>Size: <strong>{product.weight}</strong></span>
              </div>
            )}
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Natural ingredients, vegan-friendly</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Truck className="h-4 w-4 text-blue-600" />
              <span>Free UK delivery on orders over £30</span>
            </div>
          </div>

          {/* Quantity & Add to Cart */}
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Label htmlFor="quantity">Quantity:</Label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  className="h-10 w-10 p-0"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  max={product.stockQuantity}
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                  className="w-20 text-center"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuantityChange(quantity + 1)}
                  disabled={quantity >= product.stockQuantity}
                  className="h-10 w-10 p-0"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleAddToCart}
                disabled={product.stockQuantity === 0}
                className="flex-1 bg-primary hover:bg-primary-light"
                size="lg"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                {product.stockQuantity === 0 ? 'Out of Stock' : 'Add to Cart'}
              </Button>
              <Button variant="outline" size="lg" className="px-4">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="px-4">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Safety Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-amber-800 mb-1">Important Notice</p>
                <p className="text-amber-700">
                  This product is not intended to diagnose, treat, cure, or prevent any disease. 
                  Consult your healthcare provider before use if pregnant, nursing, or have medical conditions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <div className="mb-16">
        <div className="border-b">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  selectedTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-8">
          {selectedTab === 'description' && (
            <div className="prose max-w-none">
              <p className="text-gray-600 leading-relaxed">{product.description}</p>
              {product.benefits && (
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4">Benefits</h3>
                  <div className="text-gray-600 whitespace-pre-line">{product.benefits}</div>
                </div>
              )}
            </div>
          )}

          {selectedTab === 'ingredients' && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Ingredients</h3>
              {product.ingredients ? (
                <div className="text-gray-600 whitespace-pre-line">{product.ingredients}</div>
              ) : (
                <p className="text-gray-500">Ingredient information not available.</p>
              )}
            </div>
          )}

          {selectedTab === 'usage' && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Usage Instructions</h3>
              {product.usageInstructions ? (
                <div className="text-gray-600 whitespace-pre-line">{product.usageInstructions}</div>
              ) : (
                <p className="text-gray-500">Usage instructions not available.</p>
              )}
            </div>
          )}

          {selectedTab === 'reviews' && (
            <div className="space-y-8">
              {/* Reviews List */}
              {product.reviews && product.reviews.length > 0 ? (
                <div className="space-y-6">
                  {product.reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating
                                      ? 'fill-yellow-400 text-yellow-400'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                            {review.verified && (
                              <Badge variant="secondary" className="text-xs">
                                Verified Purchase
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-gray-500">
                            {new Date(review.createdAt!).toLocaleDateString()}
                          </div>
                        </div>
                        {review.title && (
                          <h4 className="font-semibold mb-2">{review.title}</h4>
                        )}
                        <p className="text-gray-600">{review.comment}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Star className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews yet</h3>
                  <p className="text-gray-500">Be the first to review this product!</p>
                </div>
              )}

              <Separator />

              {/* Review Form */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Write a Review</h3>
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="rating">Rating *</Label>
                    <div className="flex items-center gap-2 mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setReviewData({ ...reviewData, rating: star })}
                          className="focus:outline-none"
                        >
                          <Star
                            className={`h-6 w-6 ${
                              star <= reviewData.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-gray-300 hover:text-yellow-400'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="title">Review Title</Label>
                    <Input
                      id="title"
                      value={reviewData.title}
                      onChange={(e) => setReviewData({ ...reviewData, title: e.target.value })}
                      placeholder="Optional review title"
                    />
                  </div>

                  <div>
                    <Label htmlFor="comment">Your Review *</Label>
                    <Textarea
                      id="comment"
                      required
                      value={reviewData.comment}
                      onChange={(e) => setReviewData({ ...reviewData, comment: e.target.value })}
                      placeholder="Share your experience with this product..."
                      rows={4}
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={reviewMutation.isPending || !reviewData.comment.trim()}
                    className="bg-primary hover:bg-primary-light"
                  >
                    {reviewMutation.isPending ? 'Submitting...' : 'Submit Review'}
                  </Button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
