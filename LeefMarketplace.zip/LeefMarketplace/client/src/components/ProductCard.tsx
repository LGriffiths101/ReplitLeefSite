import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Star, Package, ShoppingCart, Eye, Leaf, Shield } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { Product } from '@shared/schema';

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

export function ProductCard({ product, featured = false }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
    }).format(parseFloat(price));
  };

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (product.stockQuantity === 0) {
      toast({
        title: "Out of stock",
        description: "This product is currently out of stock.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      addToCart(product, 1);
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add product to cart. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'massage':
        return '💆';
      case 'active':
        return '🏃';
      case 'skincare':
        return '🌟';
      default:
        return '🌿';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'massage':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'skincare':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const stockStatus = product.stockQuantity > 0 ? 'In Stock' : 'Out of Stock';
  const stockColor = product.stockQuantity > 0 ? 'text-green-600' : 'text-red-600';

  return (
    <Card className={`group relative overflow-hidden transition-all duration-300 hover:shadow-xl ${featured ? 'ring-2 ring-primary' : ''}`}>
      <Link href={`/products/${product.slug}`}>
        <div className="aspect-square relative overflow-hidden bg-gray-50">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.imageAlt || product.name}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center">
              <Package className="h-16 w-16 text-gray-300" />
            </div>
          )}
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {featured && (
              <Badge className="bg-primary text-white">
                Featured
              </Badge>
            )}
            {product.stockQuantity === 0 && (
              <Badge variant="destructive">
                Out of Stock
              </Badge>
            )}
          </div>

          {/* Quick View Button */}
          <div className="absolute top-3 right-3 opacity-0 transition-opacity group-hover:opacity-100">
            <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
              <Eye className="h-4 w-4" />
            </Button>
          </div>

          {/* Overlay with product highlights */}
          <div className="absolute inset-0 bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
            <div className="absolute bottom-3 left-3 right-3">
              <div className="flex items-center gap-2 text-white text-xs">
                <div className="flex items-center gap-1">
                  <Leaf className="h-3 w-3" />
                  <span>Natural</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  <span>UK Compliant</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Link>

      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Badge variant="secondary" className={getCategoryColor(product.category)}>
            <span className="mr-1">{getCategoryIcon(product.category)}</span>
            {product.category}
          </Badge>
          
          {/* Mock rating - replace with actual reviews data */}
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-gray-600">4.8</span>
          </div>
        </div>

        <Link href={`/products/${product.slug}`}>
          <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-1 hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
          {product.shortDescription || product.description}
        </p>

        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-2xl font-bold text-gray-900">
              {formatPrice(product.price)}
            </div>
            <div className="text-xs text-gray-500">inc. VAT</div>
          </div>
          <div className={`text-sm font-medium ${stockColor}`}>
            {stockStatus}
          </div>
        </div>

        {/* Product highlights */}
        {product.cbdContent && (
          <div className="text-xs text-gray-500 mb-2">
            CBD Content: {product.cbdContent}
          </div>
        )}
        {product.weight && (
          <div className="text-xs text-gray-500 mb-4">
            Size: {product.weight}
          </div>
        )}
      </CardContent>

      <CardFooter className="p-6 pt-0">
        <Button
          onClick={handleAddToCart}
          disabled={isLoading || product.stockQuantity === 0}
          className="w-full bg-primary hover:bg-primary-light disabled:opacity-50"
        >
          {isLoading ? (
            "Adding..."
          ) : product.stockQuantity === 0 ? (
            "Out of Stock"
          ) : (
            <>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
