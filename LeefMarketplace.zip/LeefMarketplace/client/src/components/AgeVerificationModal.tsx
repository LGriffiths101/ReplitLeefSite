import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Shield, AlertTriangle } from 'lucide-react';
import { useLocalStorage } from '@/hooks/useLocalStorage';

export function AgeVerificationModal() {
  const [ageVerified, setAgeVerified] = useLocalStorage('leef_age_verified', false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!ageVerified) {
      setIsOpen(true);
    }
  }, [ageVerified]);

  const handleVerifyAge = () => {
    setAgeVerified(true);
    setIsOpen(false);
  };

  const handleExitSite = () => {
    window.location.href = 'https://www.google.com';
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" hideCloseButton>
        <DialogHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-100">
            <Shield className="h-8 w-8 text-amber-600" />
          </div>
          <DialogTitle className="text-2xl font-semibold">Age Verification Required</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="text-center">
            <div className="mb-4 flex items-center justify-center gap-2 text-amber-600">
              <AlertTriangle className="h-5 w-5" />
              <span className="text-sm font-medium">UK Legal Requirement</span>
            </div>
            <p className="text-gray-600">
              You must be 18 or older to purchase CBD products in the United Kingdom. 
              This is required by UK law for all CBD wellness products.
            </p>
          </div>

          <div className="space-y-3">
            <Button onClick={handleVerifyAge} className="w-full bg-primary hover:bg-primary-light">
              I am 18 or older
            </Button>
            <Button 
              onClick={handleExitSite} 
              variant="outline" 
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              I am under 18
            </Button>
          </div>

          <div className="text-center text-xs text-gray-500">
            By clicking "I am 18 or older", you confirm that you are of legal age to purchase CBD products in the UK.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
