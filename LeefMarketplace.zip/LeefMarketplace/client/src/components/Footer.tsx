import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube,
  Mail,
  Phone,
  MapPin,
  Leaf,
  Shield,
  Award,
  Heart
} from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    quickLinks: [
      { name: 'Shop', href: '/shop' },
      { name: 'About Us', href: '/about' },
      { name: 'Wellness', href: '/wellness' },
      { name: 'Contact', href: '/contact' },
    ],
    customerCare: [
      { name: 'Shipping Info', href: '/shipping' },
      { name: 'Returns & Exchanges', href: '/returns' },
      { name: 'Track Your Order', href: '/track-order' },
      { name: 'Size Guide', href: '/size-guide' },
      { name: 'FAQ', href: '/wellness#faq' },
    ],
    legal: [
      { name: 'Terms & Conditions', href: '/terms' },
      { name: 'Privacy Policy', href: '/privacy' },
      { name: 'Cookie Policy', href: '/cookies' },
      { name: 'GDPR Compliance', href: '/gdpr' },
      { name: 'Accessibility', href: '/accessibility' },
    ],
  };

  const socialLinks = [
    { name: 'Facebook', href: 'https://facebook.com/leefwellness', icon: Facebook },
    { name: 'Instagram', href: 'https://instagram.com/leefwellness', icon: Instagram },
    { name: 'Twitter', href: 'https://twitter.com/leefwellness', icon: Twitter },
    { name: 'YouTube', href: 'https://youtube.com/leefwellness', icon: Youtube },
  ];

  const trustBadges = [
    { icon: Shield, label: 'UK Compliant', description: '< 0.2% THC' },
    { icon: Award, label: 'Lab Tested', description: 'Third-party verified' },
    { icon: Leaf, label: 'Natural', description: '100% Organic' },
    { icon: Heart, label: 'Vegan', description: 'Cruelty-free' },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Brand Column */}
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h3 className="text-2xl font-serif font-bold mb-4">Leef</h3>
                <p className="text-gray-300 mb-6 max-w-sm">
                  Pure CBD for your wellbeing. Natural, tested, and UK-compliant wellness products 
                  to support your journey to better health.
                </p>
              </div>

              {/* Contact Info */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-primary" />
                  <span className="text-sm">0800 123 4567</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-primary" />
                  <span className="text-sm">hello@leef.co.uk</span>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="h-4 w-4 text-primary mt-0.5" />
                  <div className="text-sm">
                    <div>123 Wellness Street</div>
                    <div>London, W1A 1AA</div>
                    <div>United Kingdom</div>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div>
                <p className="text-sm text-gray-400 mb-3">Follow us:</p>
                <div className="flex space-x-4">
                  {socialLinks.map((social) => {
                    const IconComponent = social.icon;
                    return (
                      <a
                        key={social.name}
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-400 hover:text-white transition-colors"
                        aria-label={social.name}
                      >
                        <IconComponent className="h-5 w-5" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-3">
                {footerLinks.quickLinks.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href}>
                      <a className="text-gray-300 hover:text-white transition-colors text-sm">
                        {link.name}
                      </a>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Customer Care */}
            <div>
              <h4 className="font-semibold mb-4">Customer Care</h4>
              <ul className="space-y-3">
                {footerLinks.customerCare.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href}>
                      <a className="text-gray-300 hover:text-white transition-colors text-sm">
                        {link.name}
                      </a>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-3">
                {footerLinks.legal.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href}>
                      <a className="text-gray-300 hover:text-white transition-colors text-sm">
                        {link.name}
                      </a>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <Separator className="bg-gray-800" />

        {/* Newsletter Section */}
        <div className="py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h4 className="text-xl font-semibold mb-2">Stay Connected</h4>
              <p className="text-gray-300 text-sm">
                Get wellness tips, product updates, and exclusive offers delivered to your inbox.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Input
                type="email"
                placeholder="Enter your email address"
                className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-400"
              />
              <Button className="bg-primary hover:bg-primary-light whitespace-nowrap">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <Separator className="bg-gray-800" />

        {/* Trust Badges */}
        <div className="py-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {trustBadges.map((badge, index) => {
              const IconComponent = badge.icon;
              return (
                <div key={index} className="flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full w-10 h-10 flex items-center justify-center flex-shrink-0">
                    <IconComponent className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">{badge.label}</div>
                    <div className="text-xs text-gray-400">{badge.description}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <Separator className="bg-gray-800" />

        {/* Bottom Bar */}
        <div className="py-6">
          <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
            <div className="text-gray-400 text-sm text-center lg:text-left">
              <p>
                © {currentYear} Leef. All rights reserved. | Company No: 12345678 | VAT No: GB123456789
              </p>
              <p className="mt-1">
                Registered in England and Wales. Regulated by the Food Standards Agency.
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-gray-400 text-sm">Payment Methods:</div>
              <div className="flex items-center gap-2">
                <div className="bg-gray-800 rounded px-2 py-1 text-xs border border-gray-700">
                  Visa
                </div>
                <div className="bg-gray-800 rounded px-2 py-1 text-xs border border-gray-700">
                  Mastercard
                </div>
                <div className="bg-gray-800 rounded px-2 py-1 text-xs border border-gray-700">
                  PayPal
                </div>
                <div className="bg-gray-800 rounded px-2 py-1 text-xs border border-gray-700">
                  Apple Pay
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Disclaimer */}
        <div className="border-t border-gray-800 py-4">
          <div className="text-xs text-gray-500 text-center">
            <p>
              Important: These products are not intended to diagnose, treat, cure, or prevent any disease. 
              Always consult with a healthcare professional before using CBD products. 
              Keep out of reach of children. For adults 18+ only.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
