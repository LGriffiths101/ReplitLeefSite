import { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Shield, Truck, Heart, Users } from 'lucide-react';

const faqData = [
  {
    id: '1',
    category: 'Legal',
    icon: Shield,
    question: 'Is CBD legal in the UK?',
    answer: 'Yes, CBD is completely legal in the UK when it contains less than 0.2% THC. All our products are fully compliant with UK regulations and are third-party tested for purity and compliance. We ensure all our products meet the strict requirements set by the Food Standards Agency (FSA) and the Medicines and Healthcare products Regulatory Agency (MHRA).',
  },
  {
    id: '2',
    category: 'Usage',
    icon: Heart,
    question: 'How do I use CBD products?',
    answer: 'Start with a small amount and gradually increase as needed. Our products come with detailed usage instructions on the packaging. For topical products like our balms and creams, apply to clean skin and massage gently. Always read the product instructions carefully and consult with a healthcare professional if you have any concerns about usage.',
  },
  {
    id: '3',
    category: 'Legal',
    icon: Shield,
    question: 'What are the benefits of CBD?',
    answer: 'CBD may help with relaxation and general wellbeing. However, we cannot make specific medical or health claims about our products as they are not intended to diagnose, treat, cure, or prevent any disease. Please consult with a healthcare professional for medical advice. Our products are designed to support your wellness journey as part of a healthy lifestyle.',
  },
  {
    id: '4',
    category: 'Shipping',
    icon: Truck,
    question: 'Do you offer free delivery?',
    answer: 'Yes, we offer free UK delivery on orders over £30. Standard delivery takes 2-3 business days via Royal Mail. Express next-day delivery options are also available at checkout for £5.99. All orders are packaged discreetly and securely. We currently only deliver within the United Kingdom.',
  },
  {
    id: '5',
    category: 'Policy',
    icon: Users,
    question: 'Can I return products?',
    answer: 'Yes, we offer a 30-day return policy for unopened products in their original packaging. Due to hygiene regulations and UK law, opened CBD products cannot be returned unless they are faulty or damaged. If you receive a defective product, please contact us within 7 days of delivery. Please see our full returns policy for complete details.',
  },
  {
    id: '6',
    category: 'Usage',
    icon: Heart,
    question: 'Are there any side effects?',
    answer: 'CBD is generally well-tolerated by most people. Some users may experience mild side effects such as drowsiness, dry mouth, or changes in appetite. These effects are typically mild and temporary. If you are pregnant, nursing, or taking medications, please consult with your healthcare provider before using CBD products.',
  },
  {
    id: '7',
    category: 'Legal',
    icon: Shield,
    question: 'Do I need to be 18+ to purchase?',
    answer: 'Yes, you must be 18 years or older to purchase CBD products in the UK. This is a legal requirement and we verify age before processing any orders. We take this responsibility seriously to ensure compliance with UK regulations regarding CBD product sales.',
  },
  {
    id: '8',
    category: 'Shipping',
    icon: Truck,
    question: 'How do you package orders?',
    answer: 'All orders are packaged discreetly in plain packaging with no external indication of the contents. We use sustainable packaging materials wherever possible and ensure all products are securely protected during transit. You will receive tracking information once your order is dispatched.',
  },
];

const categories = [
  { name: 'All', value: 'all' },
  { name: 'Legal', value: 'Legal' },
  { name: 'Usage', value: 'Usage' },
  { name: 'Shipping', value: 'Shipping' },
  { name: 'Policy', value: 'Policy' },
];

export function FAQ() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredFAQs = selectedCategory === 'all' 
    ? faqData 
    : faqData.filter(faq => faq.category === selectedCategory);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Legal':
        return 'bg-blue-100 text-blue-800';
      case 'Usage':
        return 'bg-green-100 text-green-800';
      case 'Shipping':
        return 'bg-purple-100 text-purple-800';
      case 'Policy':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-8">
      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category.value}
            onClick={() => setSelectedCategory(category.value)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === category.value
                ? 'bg-primary text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* FAQ Accordion */}
      <Accordion type="single" collapsible className="space-y-4">
        {filteredFAQs.map((faq) => {
          const IconComponent = faq.icon;
          return (
            <AccordionItem 
              key={faq.id} 
              value={faq.id}
              className="border border-gray-200 rounded-lg px-6 py-2"
            >
              <AccordionTrigger className="text-left hover:no-underline group">
                <div className="flex items-center gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 flex-shrink-0">
                    <IconComponent className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 group-hover:text-primary transition-colors">
                        {faq.question}
                      </h3>
                      <Badge variant="secondary" className={getCategoryColor(faq.category)}>
                        {faq.category}
                      </Badge>
                    </div>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 pb-2">
                <div className="ml-14 text-gray-600 leading-relaxed">
                  {faq.answer}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>

      {filteredFAQs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No FAQs found for the selected category.</p>
        </div>
      )}
    </div>
  );
}
