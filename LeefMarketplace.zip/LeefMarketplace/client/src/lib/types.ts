export interface CartItem {
  id: number;
  name: string;
  price: number;
  imageUrl: string | null;
  quantity: number;
  maxQuantity: number;
  slug: string;
}

export interface CheckoutFormData {
  billingFirstName: string;
  billingLastName: string;
  billingEmail: string;
  billingPhone: string;
  billingAddress1: string;
  billingAddress2?: string;
  billingCity: string;
  billingCounty?: string;
  billingPostcode: string;
  billingCountry: string;
  
  shippingFirstName: string;
  shippingLastName: string;
  shippingAddress1: string;
  shippingAddress2?: string;
  shippingCity: string;
  shippingCounty?: string;
  shippingPostcode: string;
  shippingCountry: string;
  
  sameAsShipping: boolean;
  agreeToTerms: boolean;
  marketingConsent: boolean;
  notes?: string;
}

export interface OrderSummary {
  subtotal: number;
  vatAmount: number;
  shippingAmount: number;
  total: number;
  itemCount: number;
}

export const UK_COUNTIES = [
  'Avon', 'Bedfordshire', 'Berkshire', 'Borders', 'Buckinghamshire', 'Cambridgeshire',
  'Central', 'Cheshire', 'Cleveland', 'Clwyd', 'Cornwall', 'County Antrim', 'County Armagh',
  'County Down', 'County Fermanagh', 'County Londonderry', 'County Tyrone', 'Cumbria',
  'Derbyshire', 'Devon', 'Dorset', 'Dumfries and Galloway', 'Durham', 'Dyfed', 'East Sussex',
  'Essex', 'Fife', 'Gloucestershire', 'Grampian', 'Greater Manchester', 'Gwent', 'Gwynedd',
  'Hampshire', 'Hereford and Worcester', 'Hertfordshire', 'Highland', 'Humberside', 'Isle of Wight',
  'Kent', 'Lancashire', 'Leicestershire', 'Lincolnshire', 'Lothian', 'Merseyside', 'Mid Glamorgan',
  'Norfolk', 'North Yorkshire', 'Northamptonshire', 'Northumberland', 'Nottinghamshire',
  'Orkney Islands', 'Oxfordshire', 'Powys', 'Rutland', 'Shetland Islands', 'Shropshire',
  'Somerset', 'South Glamorgan', 'South Yorkshire', 'Staffordshire', 'Stirling', 'Suffolk',
  'Surrey', 'Tayside', 'Tyne and Wear', 'Warwickshire', 'West Glamorgan', 'West Midlands',
  'West Sussex', 'West Yorkshire', 'Western Isles', 'Wiltshire', 'Worcestershire'
];
